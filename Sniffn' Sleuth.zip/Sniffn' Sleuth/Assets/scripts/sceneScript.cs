﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class sceneScript : MonoBehaviour {

	public void startPress() {
		SceneManager.LoadScene("level01");
	}
}