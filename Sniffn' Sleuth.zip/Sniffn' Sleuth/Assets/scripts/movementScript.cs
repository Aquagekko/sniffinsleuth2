﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movementScript : MonoBehaviour {

	public void moveForward() {
		transform.Translate(Vector3.forward * Time.deltaTime);
	}
	public void moveBackwards() {
		transform.Translate(Vector3.forward * -Time.deltaTime);
	}
	public void moveLeft() {
		transform.Translate(Vector3.left * Time.deltaTime);
	}
	public void moveRight() {
		transform.Translate(Vector3.right * Time.deltaTime);
	}
	public void turnLeft() {
		transform.Rotate(0f, -.5f, 0f);
	}
	public void turnRight() {
	    transform.Rotate(0f, .5f, 0f);
	}
}
