﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class buttonScript : MonoBehaviour, IPointerDownHandler, IPointerUpHandler {

    public movementScript movementScript;
	public bool holding;
	
	void Start() {
		holding = false;
	}
	
	void Update () {
		if (holding == true) {
			if (this.name == "forwardButton") {
				movementScript.moveForward();
			}
			if (this.name == "backwardsButton") {
				movementScript.moveBackwards();
			}
			if (this.name == "leftButton") {
				movementScript.moveLeft();
			}
			if (this.name == "rightButton") {
				movementScript.moveRight();
			}
			if (this.name == "turnLButton") {
				movementScript.turnLeft();
			}
			if (this.name == "turnRButton") {
				movementScript.turnRight();
			}
		}
	}
	
	public void OnPointerDown(PointerEventData eventData) {
		holding = true;
	}
	public void OnPointerUp(PointerEventData eventData) {
		holding = false;
	}
}
